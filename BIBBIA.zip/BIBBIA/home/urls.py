from django.urls import path
from . import views

app_name = 'home'

urlpatterns = [
    path('', views.homepage, name='homepage'),  # Homepage
    path('canone/<str:canon>/categoria/<str:category_name>/', views.category_view, name='category'),  # Categoria generica

]
