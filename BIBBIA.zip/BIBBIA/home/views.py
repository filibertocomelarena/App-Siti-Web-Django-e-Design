from django.shortcuts import render, get_object_or_404
from .models import Categoria, Canone, Versetto, Testamento, Libro, Capitolo, Vangelo
from django.http import JsonResponse


def homepage(request):
    """Gestisce la home con selezione del canone."""
    canoni = Canone.objects.all()  # Aggiungi la lista dei canoni
    return render(request, 'home/homepage.html', {'canoni': canoni})


from django.shortcuts import render

# Mappa dei canoni con le rispettive categorie e libri
CANONS = {
    'catholic': [
        {"name": "Pentateuch", "testament": "old", "color": "#64b5f6"},
        {"name": "Historical Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Wisdom Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Prophetic Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Deuterocanonical", "testament": "old", "color": "#64b5f6"},
        {"name": "Gospels", "testament": "new", "color": "#ffb74d"},
        {"name": "Acts of the Apostles", "testament": "new", "color": "#ffb74d"},
        {"name": "Pauline Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "General Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "Revelation", "testament": "new", "color": "#ffb74d"},
    ],
    'hebrew': [
        {"name": "Torah", "testament": "", "color": "#64b5f6"},
        {"name": "Nevi'im (Prophets)", "testament": "", "color": "#64b5f6"},
        {"name": "Ketuvim (Writings)", "testament": "", "color": "#64b5f6"},
    ],
    'protestant': [
        {"name": "Pentateuch", "testament": "old", "color": "#64b5f6"},
        {"name": "Historical Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Wisdom Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Prophetic Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Gospels", "testament": "new", "color": "#ffb74d"},
        {"name": "Acts of the Apostles", "testament": "new", "color": "#ffb74d"},
        {"name": "Pauline Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "General Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "Revelation", "testament": "new", "color": "#ffb74d"},
    ],
    'orthodox': [
        {"name": "Pentateuch", "testament": "old", "color": "#64b5f6"},
        {"name": "Historical Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Wisdom Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Prophetic Books", "testament": "old", "color": "#64b5f6"},
        {"name": "Gospels", "testament": "new", "color": "#ffb74d"},
        {"name": "Acts of the Apostles", "testament": "new", "color": "#ffb74d"},
        {"name": "Pauline Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "General Epistles", "testament": "new", "color": "#ffb74d"},
        {"name": "Revelation", "testament": "new", "color": "#ffb74d"},
    ]
}


def category_view(request, canon, category_name):
    categories = CANONS.get(canon, [])
    category_data = next((cat for cat in categories if cat['name'].lower().replace(" ", "-") == category_name), None)

    if category_name.lower() == 'gospels':
        # Lista dei nomi dei file dei Vangeli
        gospels = ["matteo", "marco", "luca", "giovanni"]
        category_data = {
            'name': "Gospels",
            'testament': "New Testament",
            'color': "#ffb74d",
            'gospels': gospels  # Passiamo i nomi dei file al template
        }

    if category_data:
        return render(request, 'home/categoria.html', {'category': category_data})
    else:
        return render(request, 'category_not_found.html')

