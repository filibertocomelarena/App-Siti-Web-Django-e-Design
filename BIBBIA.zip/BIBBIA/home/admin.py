from django.contrib import admin
from .models import Testamento, Libro, Capitolo, Versetto, Annotazione

admin.site.register(Testamento)
admin.site.register(Libro)
admin.site.register(Capitolo)
admin.site.register(Versetto)
admin.site.register(Annotazione)

from django.contrib import admin

# Register your models here.
