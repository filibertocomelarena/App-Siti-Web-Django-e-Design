from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class Canone(models.Model):
    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome


class Testamento(models.Model):
    nome = models.CharField(max_length=100)
    descrizione = models.TextField()
    canone_religioso = models.ForeignKey(Canone, on_delete=models.CASCADE, related_name="testamenti")

    def __str__(self):
        return self.nome


# Modello per le categorie, che dipendono dal canone
class Categoria(models.Model):
    nome = models.CharField(max_length=100)
    descrizione = models.TextField()

    def __str__(self):
        return self.nome


# Modello per i libri (incluso i vangeli)
class Libro(models.Model):
    titolo = models.CharField(max_length=200, default='Titolo predefinito')
    descrizione = models.TextField(default="")
    testamento = models.ForeignKey(Testamento, on_delete=models.CASCADE, related_name='libri')
    categorie = models.ManyToManyField(Categoria, related_name='libri')

    def __str__(self):
        return self.titolo


# Modello Capitolo
class Capitolo(models.Model):
    libro = models.ForeignKey(Libro, on_delete=models.CASCADE, related_name='capitoli')
    numero = models.PositiveIntegerField()

    def __str__(self):
        return f"Capitolo {self.numero} di {self.libro.titolo}"  # Corretto 'nome' in 'titolo'


# Modello Versetto
class Versetto(models.Model):
    capitolo = models.ForeignKey(Capitolo, on_delete=models.CASCADE, related_name='versetti')
    numero = models.PositiveIntegerField()
    testo = models.TextField()

    class Meta:
        ordering = ['numero']

    def clean(self):
        # Assicurati che ogni versetto in un capitolo abbia un numero unico
        if Versetto.objects.filter(capitolo=self.capitolo, numero=self.numero).exists():
            raise ValidationError(f"Versetto {self.numero} già esiste nel capitolo {self.capitolo.numero}.")

    def __str__(self):
        return f"Versetto {self.numero} ({self.capitolo.libro.titolo} {self.capitolo.numero})"


# Modello Annotazione
class Annotazione(models.Model):
    versetto = models.ForeignKey(Versetto, on_delete=models.CASCADE)
    testo = models.TextField()
    utente = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"Annotazione su {self.versetto}"


# Modello Contenuto (per eventuali contenuti aggiuntivi)
class Contenuto(models.Model):
    titolo = models.CharField(max_length=200)
    testo = models.TextField()
    categoria = models.ForeignKey(Categoria, related_name='contenuti', on_delete=models.CASCADE)

    def __str__(self):
        return self.titolo


# Modello per i Vangeli specifici (Matteo, Marco, Luca, Giovanni)
class Vangelo(models.Model):
    titolo = models.CharField(max_length=100, choices=[
        ('matteo', 'Matteo'),
        ('marco', 'Marco'),
        ('luca', 'Luca'),
        ('giovanni', 'Giovanni')
    ])
    descrizione = models.TextField(default="Testo del Vangelo")
    testo = models.TextField()  # Contenuto del Vangelo (testo o un riferimento ai file)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE, related_name="vangeli")

    def __str__(self):
        return f"Vangelo di {self.titolo.title()}"
